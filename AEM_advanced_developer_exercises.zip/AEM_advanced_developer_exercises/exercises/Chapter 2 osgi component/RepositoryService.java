package com.adobe.training.core;

public interface RepositoryService {
    public String getRepositoryName();
}